-- Ejemplo de autogestión del taller de la PO cargado sobre belc_ddl_v4 + belc_datos_iniciales_v4.
SET FOREIGN_KEY_CHECKS=1;
SET @ach=(SELECT transaction_type_id FROM belpc_transaction_type WHERE code='TRF_TERCEROS_ACH');
SET @usd=(SELECT currency_id FROM belpc_currency WHERE code='USD');
SET @cte=(SELECT product_type_id FROM belpc_product_type WHERE code='CTE');
SET @dpf=(SELECT product_type_id FROM belpc_product_type WHERE code='DPF');
SET @tdc=(SELECT product_type_id FROM belpc_product_type WHERE code='TDC');
-- Estructura organizacional
INSERT INTO belpc_economic_group (economic_group_id,name,administration_type) VALUES (1,'Grupo Ejemplo PO','D');
INSERT INTO belpc_company (company_id,economic_group_id,name,core_company_id) VALUES (1,1,'Empresa 1','C1'),(2,1,'Empresa 2','C2'),(3,1,'Empresa 3','C3');
INSERT INTO belpc_linked_product (linked_product_id,company_id,economic_group_id,core_module,core_product_id,product_type_id,currency_id,masked_number,link_status) VALUES
 (11,1,1,'CTA','E1C1',@cte,@usd,'****1101','ACTIVO'),(12,1,1,'CTA','E1C2',@cte,@usd,'****1102','ACTIVO'),(13,1,1,'DPF','E1D1',@dpf,@usd,'****1103','ACTIVO'),
 (21,2,1,'CTA','E2C1',@cte,@usd,'****2101','ACTIVO'),(22,2,1,'CTA','E2C2',@cte,@usd,'****2102','ACTIVO'),
 (31,3,1,'CTA','E3C1',@cte,@usd,'****3101','ACTIVO'),(32,3,1,'TDC','E3T1',@tdc,@usd,'****3102','ACTIVO');
-- Paso 1: grupos de productos
INSERT INTO belpc_product_group (product_group_id,economic_group_id,name) VALUES (1,1,'Empresa 1'),(2,1,'Empresa 2'),(3,1,'Cuentas del grupo');
INSERT INTO belpc_product_group_item (product_group_id,linked_product_id,economic_group_id) VALUES (1,11,1),(1,12,1),(1,13,1),(2,21,1),(2,22,1),(3,11,1),(3,12,1),(3,21,1),(3,22,1);
-- Paso 2: roles (perfil predefinido + subconjunto de permisos + grupo de productos)
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) SELECT 1,'R1','Rol Creador administrativo Empresa 1',profile_id,1 FROM belpc_profile WHERE code='CREADOR';
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) SELECT 2,'R2','Rol Creador monetario Empresa 1',profile_id,1 FROM belpc_profile WHERE code='CREADOR';
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) SELECT 3,'R3','Rol Aprobador monetario Empresa 1',profile_id,1 FROM belpc_profile WHERE code='APROBADOR';
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) SELECT 4,'R4','Rol Conciliador cuentas',profile_id,1 FROM belpc_profile WHERE code='CREADOR';
INSERT INTO belpc_role_permission (role_id,profile_id,permission_id) SELECT 1,r.profile_id,p.permission_id FROM belpc_role r JOIN belpc_permission p ON p.category='ADMINISTRATIVO' JOIN belpc_profile_permission pp ON pp.profile_id=r.profile_id AND pp.permission_id=p.permission_id WHERE r.role_id=1;
INSERT INTO belpc_role_permission (role_id,profile_id,permission_id) SELECT 2,r.profile_id,p.permission_id FROM belpc_role r JOIN belpc_permission p ON p.category='MONETARIO' AND p.code NOT IN ('ESTADO_CUENTA_DESCARGAR','EXTRACTO_MOVIMIENTOS_DESCARGAR') JOIN belpc_profile_permission pp ON pp.profile_id=r.profile_id AND pp.permission_id=p.permission_id WHERE r.role_id=2;
INSERT INTO belpc_role_permission (role_id,profile_id,permission_id) SELECT 3,r.profile_id,p.permission_id FROM belpc_role r JOIN belpc_permission p ON p.category='MONETARIO' JOIN belpc_profile_permission pp ON pp.profile_id=r.profile_id AND pp.permission_id=p.permission_id WHERE r.role_id=3;
INSERT INTO belpc_role_permission (role_id,profile_id,permission_id) SELECT 4,r.profile_id,p.permission_id FROM belpc_role r JOIN belpc_permission p ON p.code IN ('PRODUCTOS_CONSULTAR','ESTADO_CUENTA_DESCARGAR','EXTRACTO_MOVIMIENTOS_DESCARGAR') WHERE r.role_id=4;
INSERT INTO belpc_role_product_group (role_id,product_group_id,economic_group_id) VALUES (1,1,1),(2,1,1),(3,1,1),(4,3,1);
-- Paso 3: usuarios
INSERT INTO belpc_person_channel (person_id,display_name,terms_version,terms_accepted_at) VALUES
 ('juan','Juan Pérez','1',NOW()),('petra','Petra Corneles','1',NOW()),('karina','Karina Pérez','1',NOW()),('pedro','Pedro Corales','1',NOW()),('sandra','Sandra Ballesteros','1',NOW()),('luis','Luis Lima','1',NOW()),('sofia','Sofía Sánchez','1',NOW());
INSERT INTO belpc_group_user (group_user_id,economic_group_id,person_id,role_id) VALUES (1,1,'juan',1),(2,1,'petra',2),(3,1,'karina',2),(4,1,'pedro',3),(5,1,'sandra',3),(6,1,'luis',3),(7,1,'sofia',4);
-- Paso 4: flujo — tipo de transacción, límite, nivel 1 (1 de 2: Pedro, Luis) y nivel 2 (1 de 1: Sandra)
INSERT INTO belpc_approval_flow (approval_flow_id,economic_group_id,code,name) VALUES (1,1,'F1','Flujo ACH Empresa 1');
INSERT INTO belpc_approval_rule (approval_rule_id,approval_flow_id,economic_group_id,transaction_type_id,currency_id,amount_from,amount_to) VALUES (1,1,1,@ach,@usd,0,50000);
INSERT INTO belpc_approval_level (approval_level_id,approval_rule_id,economic_group_id,level_order,required_approvals) VALUES (1,1,1,1,1),(2,1,1,2,1);
INSERT INTO belpc_approval_approver (approval_level_id,group_user_id,economic_group_id) VALUES (1,4,1),(1,6,1),(2,5,1);
SELECT 'EJEMPLO DE LA PO CARGADO' AS ok;
-- Lo que la base impide del ejemplo
SELECT 'DEBE FALLAR: Rol Creador con Aprobación de transferencia' AS caso;
INSERT INTO belpc_role_permission (role_id,profile_id,permission_id) SELECT 2,r.profile_id,p.permission_id FROM belpc_role r, belpc_permission p WHERE r.role_id=2 AND p.code='TRF_TERCEROS_ACH_APROBAR';
-- Consolidado de Sofía (Rol Conciliador: cuentas del grupo)
SELECT u.person_id, r.name rol, lp.masked_number, c.name empresa
FROM belpc_group_user u JOIN belpc_role r USING(role_id) JOIN belpc_role_product_group rpg ON rpg.role_id=r.role_id
JOIN belpc_product_group_item i ON i.product_group_id=rpg.product_group_id JOIN belpc_linked_product lp ON lp.linked_product_id=i.linked_product_id
JOIN belpc_company c ON c.company_id=lp.company_id WHERE u.person_id='sofia' ORDER BY 3;
SELECT r.name, COUNT(*) permisos FROM belpc_role_permission rp JOIN belpc_role r USING(role_id) GROUP BY r.name;
