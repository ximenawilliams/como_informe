-- Pruebas de integridad BELC v4 (nombres belpc_). Ejecutar en una base belc recién creada con belc_ddl_v4.sql:
--   mysql --force belc < prueba_integridad_v4.sql
-- Cada ataque debe terminar en ERROR; al final, los conteos de casos válidos deben ser 1 1 1 1 0 0 1 1 1.
SET FOREIGN_KEY_CHECKS=1;
-- ===== Datos válidos de base =====
INSERT INTO belpc_profile (profile_id,code,name) VALUES (10,'CREADOR','Creador');
INSERT INTO belpc_economic_group (economic_group_id,name,administration_type) VALUES (1,'Grupo A','D'),(2,'Grupo B','I'),(3,'Grupo C','I');
INSERT INTO belpc_company (company_id,economic_group_id,name,core_company_id) VALUES (10,1,'Empresa de A','C-10'),(20,2,'Empresa de B','C-20');
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) VALUES (10,'R','Rol de A',10,1),(30,'R','Rol de C',10,3);
INSERT INTO belpc_person_channel VALUES ('ana','ACTIVO','Ana','v1',NOW(),NOW()),('luis','ACTIVO','Luis','v1',NOW(),NOW()),('sandra','ACTIVO','Sandra','v1',NOW(),NOW());
INSERT INTO belpc_currency (currency_id,code,name) VALUES (1,'USD','Dolar');
INSERT INTO belpc_product_type (product_type_id,code,name) VALUES (1,'CTA','Cuenta');
INSERT INTO belpc_transaction_type (transaction_type_id,code,name) VALUES (1,'TRF','Transferencia');
INSERT INTO belpc_admin_change_type (admin_change_type_id,code) VALUES (1,'ROL');
INSERT INTO belpc_document_type (document_type_id,code,name) VALUES (1,'CED','Cedula');
INSERT INTO belpc_linked_product (linked_product_id,company_id,economic_group_id,core_module,core_product_id,product_type_id,currency_id,masked_number) VALUES (100,10,1,'CTE','P1',1,1,'****1'),(200,20,2,'CTE','P2',1,1,'****2');
INSERT INTO belpc_product_group (product_group_id,economic_group_id,name) VALUES (51,1,'GP de A'),(50,2,'GP de B');
INSERT INTO belpc_group_user (group_user_id,economic_group_id,company_id,person_id,role_id) VALUES (101,1,10,'ana',10),(102,1,10,'luis',10),(103,1,10,'sandra',10);
INSERT INTO belpc_approval_flow (approval_flow_id,economic_group_id,code,name) VALUES (1,1,'F1','Flujo de A');
INSERT INTO belpc_approval_rule (approval_rule_id,approval_flow_id,economic_group_id,transaction_type_id,currency_id,amount_from,amount_to) VALUES (1,1,1,1,1,0,1000),(2,1,1,1,1,1000,5000);
INSERT INTO belpc_approval_level (approval_level_id,approval_rule_id,economic_group_id,level_order,required_approvals) VALUES (11,1,1,1,1),(21,2,1,1,1);
INSERT INTO belpc_approval_approver (approval_level_id,group_user_id,economic_group_id) VALUES (11,102,1);
INSERT INTO belpc_pending_transaction (pending_transaction_id,economic_group_id,approval_flow_id,approval_flow_version,approval_rule_id,requested_by_group_user_id,amount,currency_id,source_account_masked,destination_account_masked,expires_at) VALUES (1,1,1,1,1,101,800,1,'o','d',NOW());
INSERT INTO belpc_group_admin (economic_group_id,person_id,admin_position,group_user_id) VALUES (1,'ana',1,101);
INSERT INTO belpc_admin_approval (admin_approval_id,economic_group_id,admin_change_type_id,entity,record_id,action,record_version,required_approvals,expires_at,requested_by_person_id) VALUES (1,1,1,'role','10','EDITAR',1,1,NOW(),'luis');
SELECT 'DATOS VALIDOS CARGADOS' AS ok;

-- ===== Ataques (todos deben fallar) =====
SELECT '1a UGE grupo A + empresa B + rol C' AS ataque;
INSERT INTO belpc_group_user (economic_group_id,company_id,person_id,role_id) VALUES (1,20,'ana',30);
SELECT '1b afiliacion grupo A + empresa B + rol C' AS ataque;
INSERT INTO belpc_enrollment (economic_group_id,company_id,assigned_role_id,name,email,document_type_id,document_number,token_hash,sent_at,expires_at) VALUES (1,20,30,'X','x@x.com',1,'8-1',SHA2('t',256),NOW(),NOW());
SELECT '1c rol de A con grupo de productos de B' AS ataque;
INSERT INTO belpc_role_product_group (role_id,product_group_id,economic_group_id) VALUES (10,50,1);
SELECT '1d producto de B dentro de grupo de productos de A' AS ataque;
INSERT INTO belpc_product_group_item (product_group_id,linked_product_id,economic_group_id) VALUES (51,200,1);
SELECT '1e flujo de A con producto de B' AS ataque;
INSERT INTO belpc_approval_flow_product (approval_flow_id,linked_product_id,economic_group_id) VALUES (1,200,1);
SELECT '1f producto que dice ser del grupo A pero su empresa es de B' AS ataque;
INSERT INTO belpc_linked_product (company_id,economic_group_id,core_module,core_product_id,product_type_id,currency_id,masked_number) VALUES (20,1,'CTE','P3',1,1,'****3');
SELECT '3a decision con nivel de OTRA regla' AS ataque;
INSERT INTO belpc_pending_transaction_decision (pending_transaction_id,approval_rule_id,approval_level_id,group_user_id,decision,decided_at) VALUES (1,1,21,102,'APROBADA',NOW());
SELECT '3b decision de alguien que NO es aprobador del nivel' AS ataque;
INSERT INTO belpc_pending_transaction_decision (pending_transaction_id,approval_rule_id,approval_level_id,group_user_id,decision,decided_at) VALUES (1,1,11,103,'APROBADA',NOW());
SELECT '3c aprobador de otro grupo en un flujo de A' AS ataque;
INSERT INTO belpc_group_user (group_user_id,economic_group_id,company_id,person_id,role_id) VALUES (201,3,NULL,'sandra',30);
INSERT INTO belpc_approval_approver (approval_level_id,group_user_id,economic_group_id) VALUES (11,201,1);
SELECT '3d regla que no es del flujo de la transaccion' AS ataque;
INSERT INTO belpc_approval_flow (approval_flow_id,economic_group_id,code,name) VALUES (2,1,'F2','Otro flujo');
INSERT INTO belpc_approval_rule (approval_rule_id,approval_flow_id,economic_group_id,transaction_type_id,currency_id,amount_from,amount_to) VALUES (9,2,1,1,1,0,100);
INSERT INTO belpc_pending_transaction (economic_group_id,approval_flow_id,approval_flow_version,approval_rule_id,requested_by_group_user_id,amount,currency_id,source_account_masked,destination_account_masked,expires_at) VALUES (1,1,1,9,101,50,1,'o','d',NOW());
SELECT '6a Aprobaciones_requeridas = 0' AS ataque;
INSERT INTO belpc_admin_approval (economic_group_id,admin_change_type_id,entity,record_id,action,record_version,required_approvals,expires_at,requested_by_person_id) VALUES (1,1,'role','10','EDITAR',1,0,NOW(),'ana');
SELECT '6b decide alguien que NO es administrador' AS ataque;
INSERT INTO belpc_admin_approval_decision (admin_approval_id,economic_group_id,person_id,decision,decided_at) VALUES (1,1,'luis','APROBADA',NOW(3));

-- ===== Lo válido sigue funcionando =====
SELECT 'CASOS VALIDOS' AS prueba;
INSERT INTO belpc_pending_transaction_decision (pending_transaction_id,approval_rule_id,approval_level_id,group_user_id,decision,decided_at) VALUES (1,1,11,102,'APROBADA',NOW());
INSERT INTO belpc_admin_approval_decision (admin_approval_id,economic_group_id,person_id,decision,decided_at) VALUES (1,1,'ana','APROBADA',NOW(3));
INSERT INTO belpc_role_product_group (role_id,product_group_id,economic_group_id) VALUES (10,51,1);
INSERT INTO belpc_product_group_item (product_group_id,linked_product_id,economic_group_id) VALUES (51,100,1);
SELECT (SELECT COUNT(*) FROM belpc_pending_transaction_decision) dec_trx, (SELECT COUNT(*) FROM belpc_admin_approval_decision) dec_adm,
       (SELECT COUNT(*) FROM belpc_role_product_group) rol_gp, (SELECT COUNT(*) FROM belpc_product_group_item) gp_det,
       (SELECT COUNT(*) FROM belpc_approval_flow_product) flujo_prod, (SELECT COUNT(*) FROM belpc_enrollment) afiliaciones,
       (SELECT COUNT(*) FROM belpc_approval_approver) aprobadores, (SELECT COUNT(*) FROM belpc_pending_transaction) trx,
       (SELECT COUNT(*) FROM belpc_admin_approval) aprob_adm;
