-- Pruebas del detalle de aprobaciones administrativas en tablas (v4.2).
-- Ejecutar después de belc_ddl_v4.sql + belc_datos_iniciales_v4.sql + ejemplo_PO_autogestion_v4.sql:
--   mysql --force belc < prueba_aprobaciones_v4.sql
-- Cada caso "DEBE FALLAR" debe terminar en ERROR (6 en total).
SET FOREIGN_KEY_CHECKS=1;
INSERT INTO belpc_economic_group (economic_group_id,name,administration_type) VALUES (2,'Otro grupo','I');
INSERT INTO belpc_product_group (product_group_id,economic_group_id,name) VALUES (90,2,'GP de otro grupo');
SET @rol=(SELECT admin_change_type_id FROM belpc_admin_change_type WHERE code='ROL');
SET @cre=(SELECT profile_id FROM belpc_profile WHERE code='CREADOR');
INSERT INTO belpc_admin_approval (admin_approval_id,economic_group_id,admin_change_type_id,entity,record_id,action,record_version,required_approvals,expires_at,requested_by_person_id)
VALUES (1,1,@rol,'belpc_role','2','EDITAR',1,1,NOW()+INTERVAL 1 DAY,'juan');
SELECT 'OK: rol ANTERIOR y PROPUESTO con sus permisos y grupos de productos' AS caso;
INSERT INTO belpc_admin_approval_role (admin_approval_id,economic_group_id,snapshot,role_id,code,name,profile_id,status) VALUES
 (1,1,'ANTERIOR',2,'R2','Rol Creador monetario Empresa 1',@cre,'ACTIVO'),(1,1,'PROPUESTO',2,'R2','Rol Creador monetario Empresas 1 y 2',@cre,'ACTIVO');
INSERT INTO belpc_admin_approval_role_permission (admin_approval_id,snapshot,profile_id,permission_id)
 SELECT 1,'PROPUESTO',@cre,permission_id FROM belpc_permission WHERE code IN ('PRODUCTOS_CONSULTAR','TRF_TERCEROS_ACH_CREAR');
INSERT INTO belpc_admin_approval_role_product_group (admin_approval_id,economic_group_id,snapshot,product_group_id) VALUES (1,1,'PROPUESTO',1),(1,1,'PROPUESTO',2);
SELECT 'DEBE FALLAR: permiso propuesto fuera del perfil (Creador con aprobar)' AS caso;
INSERT INTO belpc_admin_approval_role_permission (admin_approval_id,snapshot,profile_id,permission_id)
 SELECT 1,'PROPUESTO',@cre,permission_id FROM belpc_permission WHERE code='TRF_TERCEROS_ACH_APROBAR';
SELECT 'DEBE FALLAR: grupo de productos de otro grupo económico' AS caso;
INSERT INTO belpc_admin_approval_role_product_group (admin_approval_id,economic_group_id,snapshot,product_group_id) VALUES (1,1,'PROPUESTO',90);
SELECT 'DEBE FALLAR: segundo PROPUESTO para la misma solicitud' AS caso;
INSERT INTO belpc_admin_approval_role (admin_approval_id,economic_group_id,snapshot,role_id,code,name,profile_id,status) VALUES (1,1,'PROPUESTO',2,'X','X',@cre,'ACTIVO');
SELECT 'DEBE FALLAR: snapshot inválido' AS caso;
INSERT INTO belpc_admin_approval_product_group (admin_approval_id,economic_group_id,snapshot,name,status) VALUES (1,1,'propuesto','X','ACTIVO');
SELECT 'DEBE FALLAR: detalle que dice ser de otro grupo económico' AS caso;
INSERT INTO belpc_admin_approval_product_group (admin_approval_id,economic_group_id,snapshot,name,status) VALUES (1,2,'PROPUESTO','X','ACTIVO');
SELECT 'DEBE FALLAR: invitar usuario con rol de otro grupo' AS caso;
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) VALUES (90,'RX','Rol otro grupo',@cre,2);
INSERT INTO belpc_admin_approval_user (admin_approval_id,economic_group_id,snapshot,name,email,role_id,status) VALUES (1,1,'PROPUESTO','Ana','a@x.com',90,'ACTIVO');
SELECT 'Detalle de la solicitud 1' AS caso;
SELECT r.snapshot, r.name, (SELECT COUNT(*) FROM belpc_admin_approval_role_permission p WHERE p.admin_approval_id=r.admin_approval_id AND p.snapshot=r.snapshot) permisos,
       (SELECT COUNT(*) FROM belpc_admin_approval_role_product_group g WHERE g.admin_approval_id=r.admin_approval_id AND g.snapshot=r.snapshot) grupos_productos
FROM belpc_admin_approval_role r WHERE r.admin_approval_id=1 ORDER BY r.snapshot;
