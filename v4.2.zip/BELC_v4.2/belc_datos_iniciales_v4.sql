-- =====================================================================
-- ESQUEMA belc · Datos iniciales de catálogos · v4.1
-- Ejecutar después de belc_ddl_v4.sql (changeset de datos aparte en Liquibase).
--
-- Fuente: taller "Banca en Línea Comercial – Release 1" (PO):
--   * Permisos por perfil CREADOR, APROBADOR y EJECUTOR (láminas "Permisos por Perfil").
--     Los nombres de los permisos son los de la PO; el código es la versión técnica.
--   * Verbos: CREAR = crea y queda para aprobación · APROBAR = aprueba lo creado ·
--     GESTIONAR = el ejecutor lo hace directo.
--   * Visualización Mixto / Separado, estructura grupo → empresa → cuentas, DPF y TDC.
--   * ADMINISTRADOR (rol de sistema, observación 4.2) = todos los permisos.
--   * [VALIDAR COBIS]: códigos de producto y de transacción deben coincidir con el core.
-- Se insertan por código (sin ids fijos), así funciona en cualquier ambiente.
-- =====================================================================
SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- Tipos de documento de la persona que se afilia
-- (no es necesario ser cliente del banco para ser usuario de BEL Comercial)
-- ---------------------------------------------------------------------
INSERT INTO belpc_document_type (code, name) VALUES
 ('CED', 'Cédula de identidad personal'),
 ('PAS', 'Pasaporte'),
 ('CRP', 'Carné de residente permanente');

-- ---------------------------------------------------------------------
-- Monedas
-- ---------------------------------------------------------------------
INSERT INTO belpc_currency (code, name, status) VALUES
 ('USD', 'Dólar estadounidense', 'ACTIVO'),
 ('EUR', 'Euro', 'INACTIVO');   -- activar si el core tiene productos o transferencias en EUR

-- ---------------------------------------------------------------------
-- Perfil de visualización (lo elige el banco al crear al administrador
-- y el administrador al crear a sus usuarios)
-- ---------------------------------------------------------------------
INSERT INTO belpc_display_type (code, name, description, created_by) VALUES
 ('MIXTO',    'Mixto',    'Todos los productos del grupo económico en una sola vista', 'liquibase'),
 ('SEPARADO', 'Separado', 'Productos separados por empresa del grupo económico',       'liquibase');

-- ---------------------------------------------------------------------
-- Tipos de producto (estructura organizacional del taller) [VALIDAR COBIS]
-- is_transactional = 1: puede ser cuenta origen de una transacción
-- ---------------------------------------------------------------------
INSERT INTO belpc_product_type (code, name, is_transactional, created_by) VALUES
 ('CTE', 'Cuenta corriente',        1, 'liquibase'),
 ('AHO', 'Cuenta de ahorros',       1, 'liquibase'),
 ('DPF', 'Depósito a plazo fijo',   0, 'liquibase'),
 ('TDC', 'Tarjeta de crédito',      0, 'liquibase'),
 ('PRE', 'Préstamo',                0, 'liquibase');   -- [VALIDAR] no aparece en el taller

-- ---------------------------------------------------------------------
-- Cambios administrativos que se aprueban (Aprobador administrativo)
-- ---------------------------------------------------------------------
INSERT INTO belpc_admin_change_type (code, description) VALUES
 ('GRUPO_PRODUCTO', 'Aprobación de grupos de productos'),
 ('ROL',            'Aprobación de roles'),
 ('USUARIO',        'Aprobación de usuarios'),
 ('FRECUENTE',      'Aprobación de frecuentes');

-- ---------------------------------------------------------------------
-- Permisos (nombres de la PO)
-- ---------------------------------------------------------------------
INSERT INTO belpc_permission (code, name, category) VALUES
 -- Administrativos
 ('GRUPOS_PRODUCTOS_CREAR',          'Creación de grupos de productos',            'ADMINISTRATIVO'),
 ('GRUPOS_PRODUCTOS_APROBAR',        'Aprobación de grupos de productos',          'ADMINISTRATIVO'),
 ('GRUPOS_PRODUCTOS_GESTIONAR',      'Gestión de grupos de productos',             'ADMINISTRATIVO'),
 ('ROLES_CREAR',                     'Creación de roles',                          'ADMINISTRATIVO'),
 ('ROLES_APROBAR',                   'Aprobación de roles',                        'ADMINISTRATIVO'),
 ('ROLES_GESTIONAR',                 'Gestión de roles',                           'ADMINISTRATIVO'),
 ('USUARIOS_CREAR',                  'Creación de usuarios',                       'ADMINISTRATIVO'),
 ('USUARIOS_APROBAR',                'Aprobación de usuarios',                     'ADMINISTRATIVO'),
 ('USUARIOS_GESTIONAR',              'Gestión de usuarios',                        'ADMINISTRATIVO'),
 ('USUARIOS_INACTIVAR',              'Inactivar usuarios',                         'ADMINISTRATIVO'),
 ('FRECUENTES_CREAR',                'Creación de frecuentes',                     'ADMINISTRATIVO'),
 ('FRECUENTES_APROBAR',              'Aprobación de frecuentes',                   'ADMINISTRATIVO'),
 ('FRECUENTES_GESTIONAR',            'Gestión de frecuentes',                      'ADMINISTRATIVO'),
 ('FLUJOS_GESTIONAR',                'Gestión de flujos de aprobación',            'ADMINISTRATIVO'),
 ('APROBACIONES_ADMIN_CONSULTAR',    'Consulta de aprobaciones administrativas',   'ADMINISTRATIVO'),
 ('USUARIO_PROPIO_ACTUALIZAR',       'Actualizar datos de usuario propio',         'ADMINISTRATIVO'),
 ('INICIO_PERSONALIZAR',             'Personalizar pantalla de inicio',            'ADMINISTRATIVO'),
 ('TOKEN_GESTIONAR',                 'Gestión de token',                           'ADMINISTRATIVO'),
 ('BITACORA_CONSULTAR',              'Consulta bitácora de eventos',               'ADMINISTRATIVO'),
 -- Monetarios: consultas
 ('PRODUCTOS_CONSULTAR',             'Consulta de productos y detalles',           'MONETARIO'),
 ('ESTADO_CUENTA_DESCARGAR',         'Descargar estado de cuenta',                 'MONETARIO'),
 ('EXTRACTO_MOVIMIENTOS_DESCARGAR',  'Descargar extracto de movimientos',          'MONETARIO'),
 ('CHEQUES_CONSULTAR',               'Consulta de cheques',                        'MONETARIO'),
 ('SALDO_EN_TRANSACCION_VER',        'Visualización de saldo en transacciones',    'MONETARIO'),
 ('APROBACIONES_MON_CONSULTAR',      'Consulta de aprobaciones monetarias',        'MONETARIO'),
 ('TRANSACCIONES_CONSULTAR',         'Consulta de transacciones y pagos',          'MONETARIO'),
 ('RECHAZOS_CONSULTAR',              'Consulta de rechazos de transacciones y pagos','MONETARIO'),
 ('LOTES_CONSULTAR',                 'Consulta de estado de transacciones masivas (lote)','MONETARIO'),
 ('RECURRENCIAS_CONSULTAR',          'Consulta de recurrencias pendientes de ejecución','MONETARIO'),
 ('PUNTOS_CANJEAR',                  'Canje de puntos',                            'MONETARIO'),
 -- Monetarios: transacciones (crear / aprobar / gestionar)
 ('CHEQUERA_CREAR',                  'Creación de solicitud de chequera',          'MONETARIO'),
 ('CHEQUERA_APROBAR',                'Aprobación de solicitud de chequera',        'MONETARIO'),
 ('CHEQUERA_GESTIONAR',              'Solicitar chequera',                         'MONETARIO'),
 ('CHEQUE_GERENCIA_CREAR',           'Creación de solicitud de cheque de gerencia','MONETARIO'),
 ('CHEQUE_GERENCIA_APROBAR',         'Aprobación de solicitud de cheque de gerencia','MONETARIO'),
 ('CHEQUE_GERENCIA_GESTIONAR',       'Solicitar cheque de gerencia',               'MONETARIO'),
 ('TRF_PROPIA_CREAR',                'Creación de transferencia cuentas propias',  'MONETARIO'),
 ('TRF_PROPIA_APROBAR',              'Aprobación de transferencia cuentas propias','MONETARIO'),
 ('TRF_PROPIA_GESTIONAR',            'Gestión de transferencia cuentas propias',   'MONETARIO'),
 ('TRF_TERCEROS_ACH_CREAR',          'Creación de transferencia terceros y ACH',   'MONETARIO'),
 ('TRF_TERCEROS_ACH_APROBAR',        'Aprobación de transferencia terceros y ACH', 'MONETARIO'),
 ('TRF_TERCEROS_ACH_GESTIONAR',      'Gestión de transferencia terceros y ACH',    'MONETARIO'),
 ('TRF_INTERNACIONAL_CREAR',         'Creación de transferencia internacional',    'MONETARIO'),
 ('TRF_INTERNACIONAL_APROBAR',       'Aprobación de transferencia internacional',  'MONETARIO'),
 ('TRF_INTERNACIONAL_GESTIONAR',     'Gestión de transferencia internacional',     'MONETARIO'),
 ('PAGO_SERVICIO_CREAR',             'Creación de pago de servicio',               'MONETARIO'),
 ('PAGO_SERVICIO_APROBAR',           'Aprobación de pago de servicio',             'MONETARIO'),
 ('PAGO_SERVICIO_GESTIONAR',         'Gestión de pago de servicio',                'MONETARIO'),
 ('COBRO_ACH_CREAR',                 'Creación de cobros y ACH',                   'MONETARIO'),
 ('COBRO_ACH_APROBAR',               'Aprobación de cobros y ACH',                 'MONETARIO'),
 ('COBRO_ACH_GESTIONAR',             'Gestión de cobros y ACH',                    'MONETARIO');

-- ---------------------------------------------------------------------
-- Tipos de transacción y el permiso que las aprueba [VALIDAR COBIS]
-- ---------------------------------------------------------------------
INSERT INTO belpc_transaction_type (code, name, approver_permission_id)
SELECT t.code, t.name, p.permission_id
FROM (
  SELECT 'CHEQUERA' code,     'Solicitud de chequera' name,              'CHEQUERA_APROBAR' perm UNION ALL
  SELECT 'CHEQUE_GERENCIA',   'Solicitud de cheque de gerencia',         'CHEQUE_GERENCIA_APROBAR'   UNION ALL
  SELECT 'TRF_PROPIA',        'Transferencia entre cuentas propias',     'TRF_PROPIA_APROBAR'        UNION ALL
  SELECT 'TRF_TERCEROS_ACH',  'Transferencia a terceros y ACH',          'TRF_TERCEROS_ACH_APROBAR'  UNION ALL
  SELECT 'TRF_INTERNACIONAL', 'Transferencia internacional',             'TRF_INTERNACIONAL_APROBAR' UNION ALL
  SELECT 'PAGO_SERVICIO',     'Pago de servicio',                        'PAGO_SERVICIO_APROBAR'     UNION ALL
  SELECT 'COBRO_ACH',         'Cobros y ACH',                            'COBRO_ACH_APROBAR'
) t JOIN belpc_permission p ON p.code = t.perm;

-- ---------------------------------------------------------------------
-- Perfiles predefinidos por el banco (ADMINISTRADOR ya viene en el DDL)
-- ---------------------------------------------------------------------
INSERT INTO belpc_profile (code, name, description, created_by) VALUES
 ('CREADOR',   'Creador',   'Crea operaciones administrativas y monetarias que luego se aprueban', 'liquibase'),
 ('APROBADOR', 'Aprobador', 'Aprueba operaciones administrativas y monetarias creadas por otros',   'liquibase'),
 ('EJECUTOR',  'Ejecutor',  'Gestiona directamente operaciones administrativas y monetarias',     'liquibase');

-- ---------------------------------------------------------------------
-- Permisos por perfil, tal como la matriz del taller
-- (la base rechaza un permiso de rol fuera de su perfil: observación 4.4)
-- ---------------------------------------------------------------------
INSERT INTO belpc_profile_permission (profile_id, permission_id)
SELECT pf.profile_id, pm.permission_id
FROM (
  -- CREADOR · administrativo
  SELECT 'CREADOR' prof, 'GRUPOS_PRODUCTOS_CREAR' perm UNION ALL SELECT 'CREADOR','ROLES_CREAR' UNION ALL
  SELECT 'CREADOR','USUARIOS_CREAR' UNION ALL SELECT 'CREADOR','FRECUENTES_CREAR' UNION ALL
  SELECT 'CREADOR','USUARIO_PROPIO_ACTUALIZAR' UNION ALL SELECT 'CREADOR','INICIO_PERSONALIZAR' UNION ALL
  -- CREADOR · monetario
  SELECT 'CREADOR','PRODUCTOS_CONSULTAR' UNION ALL SELECT 'CREADOR','ESTADO_CUENTA_DESCARGAR' UNION ALL
  SELECT 'CREADOR','EXTRACTO_MOVIMIENTOS_DESCARGAR' UNION ALL SELECT 'CREADOR','CHEQUES_CONSULTAR' UNION ALL
  SELECT 'CREADOR','CHEQUERA_CREAR' UNION ALL SELECT 'CREADOR','CHEQUE_GERENCIA_CREAR' UNION ALL
  SELECT 'CREADOR','TRF_PROPIA_CREAR' UNION ALL SELECT 'CREADOR','TRF_TERCEROS_ACH_CREAR' UNION ALL
  SELECT 'CREADOR','TRF_INTERNACIONAL_CREAR' UNION ALL SELECT 'CREADOR','PAGO_SERVICIO_CREAR' UNION ALL
  SELECT 'CREADOR','COBRO_ACH_CREAR' UNION ALL SELECT 'CREADOR','SALDO_EN_TRANSACCION_VER' UNION ALL
  SELECT 'CREADOR','TRANSACCIONES_CONSULTAR' UNION ALL SELECT 'CREADOR','RECHAZOS_CONSULTAR' UNION ALL
  SELECT 'CREADOR','LOTES_CONSULTAR' UNION ALL
  -- APROBADOR · administrativo
  SELECT 'APROBADOR','APROBACIONES_ADMIN_CONSULTAR' UNION ALL SELECT 'APROBADOR','GRUPOS_PRODUCTOS_APROBAR' UNION ALL
  SELECT 'APROBADOR','ROLES_APROBAR' UNION ALL SELECT 'APROBADOR','USUARIOS_APROBAR' UNION ALL
  SELECT 'APROBADOR','FRECUENTES_APROBAR' UNION ALL SELECT 'APROBADOR','USUARIO_PROPIO_ACTUALIZAR' UNION ALL
  SELECT 'APROBADOR','INICIO_PERSONALIZAR' UNION ALL SELECT 'APROBADOR','TOKEN_GESTIONAR' UNION ALL
  -- APROBADOR · monetario
  SELECT 'APROBADOR','PRODUCTOS_CONSULTAR' UNION ALL SELECT 'APROBADOR','ESTADO_CUENTA_DESCARGAR' UNION ALL
  SELECT 'APROBADOR','EXTRACTO_MOVIMIENTOS_DESCARGAR' UNION ALL SELECT 'APROBADOR','CHEQUES_CONSULTAR' UNION ALL
  SELECT 'APROBADOR','CHEQUERA_APROBAR' UNION ALL SELECT 'APROBADOR','CHEQUE_GERENCIA_APROBAR' UNION ALL
  SELECT 'APROBADOR','APROBACIONES_MON_CONSULTAR' UNION ALL SELECT 'APROBADOR','TRF_PROPIA_APROBAR' UNION ALL
  SELECT 'APROBADOR','TRF_TERCEROS_ACH_APROBAR' UNION ALL SELECT 'APROBADOR','TRF_INTERNACIONAL_APROBAR' UNION ALL
  SELECT 'APROBADOR','PAGO_SERVICIO_APROBAR' UNION ALL SELECT 'APROBADOR','COBRO_ACH_APROBAR' UNION ALL
  SELECT 'APROBADOR','TRANSACCIONES_CONSULTAR' UNION ALL SELECT 'APROBADOR','RECHAZOS_CONSULTAR' UNION ALL
  SELECT 'APROBADOR','LOTES_CONSULTAR' UNION ALL
  -- EJECUTOR · administrativo
  SELECT 'EJECUTOR','APROBACIONES_ADMIN_CONSULTAR' UNION ALL SELECT 'EJECUTOR','GRUPOS_PRODUCTOS_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','ROLES_GESTIONAR' UNION ALL SELECT 'EJECUTOR','USUARIOS_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','FRECUENTES_GESTIONAR' UNION ALL SELECT 'EJECUTOR','FLUJOS_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','USUARIO_PROPIO_ACTUALIZAR' UNION ALL SELECT 'EJECUTOR','INICIO_PERSONALIZAR' UNION ALL
  SELECT 'EJECUTOR','TOKEN_GESTIONAR' UNION ALL SELECT 'EJECUTOR','USUARIOS_INACTIVAR' UNION ALL
  SELECT 'EJECUTOR','BITACORA_CONSULTAR' UNION ALL
  -- EJECUTOR · monetario
  SELECT 'EJECUTOR','PRODUCTOS_CONSULTAR' UNION ALL SELECT 'EJECUTOR','ESTADO_CUENTA_DESCARGAR' UNION ALL
  SELECT 'EJECUTOR','EXTRACTO_MOVIMIENTOS_DESCARGAR' UNION ALL SELECT 'EJECUTOR','CHEQUES_CONSULTAR' UNION ALL
  SELECT 'EJECUTOR','CHEQUERA_GESTIONAR' UNION ALL SELECT 'EJECUTOR','CHEQUE_GERENCIA_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','APROBACIONES_MON_CONSULTAR' UNION ALL SELECT 'EJECUTOR','TRF_PROPIA_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','TRF_TERCEROS_ACH_GESTIONAR' UNION ALL SELECT 'EJECUTOR','TRF_INTERNACIONAL_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','PAGO_SERVICIO_GESTIONAR' UNION ALL SELECT 'EJECUTOR','COBRO_ACH_GESTIONAR' UNION ALL
  SELECT 'EJECUTOR','PUNTOS_CANJEAR' UNION ALL SELECT 'EJECUTOR','RECURRENCIAS_CONSULTAR' UNION ALL
  SELECT 'EJECUTOR','TRANSACCIONES_CONSULTAR' UNION ALL SELECT 'EJECUTOR','RECHAZOS_CONSULTAR' UNION ALL
  SELECT 'EJECUTOR','LOTES_CONSULTAR'
) m
JOIN belpc_profile    pf ON pf.code = m.prof
JOIN belpc_permission pm ON pm.code = m.perm;

-- ADMINISTRADOR (rol de sistema del grupo): todos los permisos
INSERT INTO belpc_profile_permission (profile_id, permission_id)
SELECT pf.profile_id, pm.permission_id
FROM belpc_profile pf JOIN belpc_permission pm ON pm.status = 'ACTIVO'
WHERE pf.code = 'ADMINISTRADOR'
  AND NOT EXISTS (SELECT 1 FROM belpc_profile_permission x WHERE x.profile_id = pf.profile_id AND x.permission_id = pm.permission_id);
