-- =====================================================================
-- ESQUEMA auditoria · Bitácora común de la banca unificada · DDL v4
-- Una persona (identity_id), una sesión, un canal y dos contextos (PERSONAL / COMERCIAL).
-- Prefijo aud_: es común a BELP y BELC. Las aplicaciones solo pueden INSERTAR.
-- Crecimiento de la tabla (particionado o archivado): pendiente D10 / TEC-018.
-- =====================================================================

SET NAMES utf8mb4;

-- =====================================================================
-- Auditoría (común BELP + BELC)
-- =====================================================================
-- Catálogo de eventos de la bitácora.
CREATE TABLE aud_event_type (
  event_type_id INT NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(15) COLLATE utf8mb4_bin NOT NULL,
  severity VARCHAR(5) COLLATE utf8mb4_bin NOT NULL,
  is_customer_visible TINYINT(1) NOT NULL DEFAULT 1,
  status VARCHAR(10) COLLATE utf8mb4_bin NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (event_type_id),
  CONSTRAINT uq_event_type__code UNIQUE (code),
  CONSTRAINT ck_event_type__category CHECK (category in ('ACCESO','SEGURIDAD','BACKOFFICE','AUTOGESTION','CONSULTA','TRANSACCION')),
  CONSTRAINT ck_event_type__severity CHECK (severity in ('BAJA','MEDIA','ALTA')),
  CONSTRAINT ck_event_type__status CHECK (status in ('ACTIVO','INACTIVO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Auditoría (común BELP + BELC) · Catálogo de eventos de la bitácora.';

-- Bitácora común de la banca unificada: solo INSERT.
CREATE TABLE aud_event_log (
  event_log_id BIGINT NOT NULL AUTO_INCREMENT,
  event_at DATETIME(3) NOT NULL,
  event_type_id INT NOT NULL,
  result VARCHAR(10) COLLATE utf8mb4_bin NOT NULL,
  channel VARCHAR(10) COLLATE utf8mb4_bin NOT NULL,
  context VARCHAR(10) COLLATE utf8mb4_bin NOT NULL,
  economic_group_id INT NULL,
  identity_id VARCHAR(64) NULL,
  backoffice_user VARCHAR(80) NULL,
  ip_address VARCHAR(45) NULL,
  device VARCHAR(400) NULL,
  session_id VARCHAR(100) NULL,
  correlation_id VARCHAR(64) NULL,
  http_method VARCHAR(10) NULL,
  uri VARCHAR(400) NULL,
  entity VARCHAR(50) NULL,
  record_id VARCHAR(50) NULL,
  previous_value JSON NULL,
  new_value JSON NULL,
  admin_approval_id INT NULL,
  pending_transaction_id INT NULL,
  amount DECIMAL(18,2) NULL,
  currency_code CHAR(3) NULL,
  source_account_masked VARCHAR(40) NULL,
  destination_account_masked VARCHAR(40) NULL,
  movement_type VARCHAR(7) NULL,
  error_code VARCHAR(30) NULL,
  detail VARCHAR(400) NULL,
  record_hash VARBINARY(32) NULL,
  PRIMARY KEY (event_log_id),
  CONSTRAINT ck_event_log__result CHECK (result in ('EXITO','FALLO','RECHAZO')),
  CONSTRAINT ck_event_log__channel CHECK (channel in ('WEB','APP','BO','API')),
  CONSTRAINT ck_event_log__context CHECK (context in ('PERSONAL','COMERCIAL','SESION')),
  CONSTRAINT ck_event_log__context_economic_group_id CHECK (context <> 'COMERCIAL' or economic_group_id is not null),
  CONSTRAINT fk_event_log__event_type FOREIGN KEY (event_type_id)
    REFERENCES aud_event_type (event_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Auditoría (común BELP + BELC) · Bitácora común de la banca unificada: solo INSERT.';
CREATE INDEX ix_event_log__correlation_id ON aud_event_log (correlation_id);
CREATE INDEX ix_event_log__event_at ON aud_event_log (event_at);
CREATE INDEX ix_event_log__economic_group_id_event_at ON aud_event_log (economic_group_id, event_at);
CREATE INDEX ix_event_log__identity_id_event_at ON aud_event_log (identity_id, event_at);
CREATE INDEX ix_event_log__session_id ON aud_event_log (session_id);

-- =====================================================================
-- Tipos de evento (los 7 iniciales + los del backlog técnico R1)
-- =====================================================================
INSERT INTO aud_event_type (code, name, category, severity, is_customer_visible) VALUES
 ('LOGIN_EXITOSO',            'Inicio de sesión exitoso',                    'ACCESO',      'BAJA',  TRUE),
 ('LOGOUT',                   'Cierre de sesión',                            'ACCESO',      'BAJA',  TRUE),
 ('CAMBIO_CONTEXTO',          'Cambio de contexto o de grupo económico',     'ACCESO',      'BAJA',  TRUE),
 ('ACCESO_DENEGADO',          'Operación denegada por falta de permiso',     'SEGURIDAD',   'ALTA',  FALSE),
 ('GRUPO_ECONOMICO_CREADO',   'Grupo económico creado',                      'BACKOFFICE',  'MEDIA', FALSE),
 ('EMPRESA_VINCULADA',        'Empresa vinculada a un grupo económico',      'BACKOFFICE',  'MEDIA', FALSE),
 ('PRODUCTO_VINCULADO',       'Producto vinculado a una empresa',            'BACKOFFICE',  'MEDIA', FALSE),
 ('ADMINISTRADOR_INVITADO',   'Primer administrador invitado por el banco',  'BACKOFFICE',  'ALTA',  FALSE),
 ('AFILIACION_COMPLETADA',    'Persona vinculada al aceptar la invitación',  'AUTOGESTION', 'MEDIA', TRUE),
 ('INVITACION_REENVIADA',     'Invitación reenviada',                        'AUTOGESTION', 'BAJA',  TRUE),
 ('USUARIO_INVITADO',         'Usuario secundario invitado',                 'AUTOGESTION', 'MEDIA', TRUE),
 ('USUARIO_EDITADO',          'Usuario secundario editado',                  'AUTOGESTION', 'MEDIA', TRUE),
 ('USUARIO_INACTIVADO',       'Usuario secundario inactivado',               'AUTOGESTION', 'ALTA',  TRUE),
 ('ROL_CREADO',               'Rol creado',                                  'AUTOGESTION', 'MEDIA', TRUE),
 ('ROL_EDITADO',              'Rol editado',                                 'AUTOGESTION', 'ALTA',  TRUE),
 ('ROL_ELIMINADO',            'Rol eliminado',                               'AUTOGESTION', 'MEDIA', TRUE),
 ('GRUPO_PRODUCTOS_CREADO',   'Grupo de productos creado',                   'AUTOGESTION', 'MEDIA', TRUE),
 ('GRUPO_PRODUCTOS_EDITADO',  'Grupo de productos modificado',               'AUTOGESTION', 'ALTA',  TRUE),
 ('GRUPO_PRODUCTOS_ELIMINADO','Grupo de productos eliminado',                'AUTOGESTION', 'MEDIA', TRUE),
 ('FLUJO_CREADO',             'Flujo de aprobación creado',                  'AUTOGESTION', 'ALTA',  TRUE),
 ('FLUJO_EDITADO',            'Flujo de aprobación editado',                 'AUTOGESTION', 'ALTA',  TRUE),
 ('FLUJO_ELIMINADO',          'Flujo de aprobación eliminado',               'AUTOGESTION', 'ALTA',  TRUE);
