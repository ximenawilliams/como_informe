-- Pruebas de belpc_frequent_beneficiary. Ejecutar en una base belc nueva con
-- belc_ddl_v4.sql + belc_datos_iniciales_v4.sql:   mysql --force belc < prueba_frecuentes_v4.sql
-- Cada caso "DEBE FALLAR" debe terminar en ERROR (4 en total).
SET FOREIGN_KEY_CHECKS=1;
INSERT INTO belpc_economic_group (economic_group_id, name, administration_type) VALUES (901,'Grupo Frecuentes A','I'),(902,'Grupo Frecuentes B','I');
SET @ach = (SELECT transaction_type_id FROM belpc_transaction_type WHERE code='TRF_TERCEROS_ACH');
SET @usd = (SELECT currency_id FROM belpc_currency WHERE code='USD');
SELECT 'OK: frecuente ACH pendiente de aprobación' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,bank_code,account_type,account_number_encrypted,account_number_hash,account_number_masked,currency_id,created_by)
VALUES (901,@ach,'Proveedor Luz','Distribuidora Uno S.A.','BGEN','CORRIENTE',UNHEX('A1B2C3'),SHA2('0401000123',256),'****0123',@usd,'ana');
SELECT 'DEBE FALLAR: misma cuenta y operación en el mismo grupo' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,account_number_encrypted,account_number_hash,account_number_masked,currency_id)
VALUES (901,@ach,'Proveedor Luz 2','Distribuidora Uno S.A.',UNHEX('A1B2C3'),SHA2('0401000123',256),'****0123',@usd);
SELECT 'DEBE FALLAR: alias repetido en el grupo' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,account_number_encrypted,account_number_hash,account_number_masked,currency_id)
VALUES (901,@ach,'Proveedor Luz','Otro',UNHEX('D4'),SHA2('999',256),'****0999',@usd);
SELECT 'DEBE FALLAR: estado no permitido' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,account_number_encrypted,account_number_hash,account_number_masked,currency_id,status)
VALUES (901,@ach,'X','X',UNHEX('D5'),SHA2('888',256),'****0888',@usd,'activo');
SELECT 'DEBE FALLAR: grupo económico inexistente' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,account_number_encrypted,account_number_hash,account_number_masked,currency_id)
VALUES (999,@ach,'Y','Y',UNHEX('D6'),SHA2('777',256),'****0777',@usd);
SELECT 'OK: la misma cuenta en OTRO grupo sí se permite' AS caso;
INSERT INTO belpc_frequent_beneficiary (economic_group_id,transaction_type_id,alias,beneficiary_name,account_number_encrypted,account_number_hash,account_number_masked,currency_id)
VALUES (902,@ach,'Proveedor Luz','Distribuidora Uno S.A.',UNHEX('A1B2C3'),SHA2('0401000123',256),'****0123',@usd);
SELECT economic_group_id, alias, account_number_masked, status FROM belpc_frequent_beneficiary ORDER BY 1;
