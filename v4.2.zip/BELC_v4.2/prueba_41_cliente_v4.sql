-- Pruebas de la 4.1 (un rol por persona y grupo) y del tipo de cliente PJ/PN.
-- Ejecutar después de belc_ddl_v4.sql + belc_datos_iniciales_v4.sql + ejemplo_PO_autogestion_v4.sql:
--   mysql --force belc < prueba_41_cliente_v4.sql
-- Cada caso "DEBE FALLAR" debe terminar en ERROR (2 en total).
SET FOREIGN_KEY_CHECKS=1;
SELECT 'OK: persona natural (PN) como cliente del grupo, como en la lámina de la PO' AS caso;
INSERT INTO belpc_company (company_id,economic_group_id,name,client_type,core_company_id) VALUES (4,1,'P Natural','PN','C4');
SELECT 'DEBE FALLAR: tipo de cliente inválido' AS caso;
INSERT INTO belpc_company (economic_group_id,name,client_type,core_company_id) VALUES (1,'X','XX','C5');
SELECT 'DEBE FALLAR: Juan con un segundo rol en el mismo grupo (vía otra empresa)' AS caso;
INSERT INTO belpc_group_user (economic_group_id,company_id,person_id,role_id) VALUES (1,2,'juan',2);
SELECT 'OK: Juan en OTRO grupo económico con otro rol' AS caso;
INSERT INTO belpc_economic_group (economic_group_id,name,administration_type) VALUES (3,'Grupo Tres','I');
INSERT INTO belpc_role (role_id,code,name,profile_id,economic_group_id) SELECT 30,'R30','Rol grupo tres',profile_id,3 FROM belpc_profile WHERE code='CREADOR';
INSERT INTO belpc_group_user (economic_group_id,person_id,role_id) VALUES (3,'juan',30);
SELECT person_id, economic_group_id, role_id FROM belpc_group_user WHERE person_id='juan' ORDER BY 2;
