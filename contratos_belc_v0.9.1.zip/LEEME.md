# Contratos OpenAPI BELC · borradores v0.9 (TEC-117)

Arquitectura entrega los 10 contratos completos en borrador, generados desde el backlog de la PO,
el DDL v4.2, el diccionario y la Guía de diseño de APIs BELC v1.
Cada responsable **revisa, completa sus pendientes y aprueba**; no escribe desde cero.

## Archivos

| Archivo | Qué es | Responsable |
|---|---|---|
| `belc-api-comun.yaml` (v1.3.0) | Piezas comunes: seguridad, errores, paginación, 202, 429 y 503 | Arquitectura |
| `belc-catalogo-errores.json` | Catálogo de errores y mensajes para Web y App: API, ForgeRock, HTTP y validaciones | Arquitectura (textos: PO y UX) |
| `sesion-contexto.yaml` | 2 operaciones | Domingo Camargo |
| `aprobaciones.yaml` | 1 operación (seguimiento del 202) | Domingo Camargo |
| `afiliacion.yaml` | 2 operaciones | David Ríos |
| `catalogos.yaml` | 2 operaciones | Edwin Lima |
| `usuarios.yaml` | 5 operaciones | Raúl Rojas |
| `productos.yaml` | 1 operación | Raúl Rojas |
| `roles.yaml` | 5 operaciones | Edwin Lima |
| `grupos-productos.yaml` | 5 operaciones | Benjamín Rodríguez |
| `flujos-aprobacion.yaml` | 6 operaciones | David Ríos |
| `backoffice.yaml` | 6 operaciones | Héctor Durán con Jonathan Vargas |
| `belc-mock-completo.yaml` | Los 10 unidos para levantar un solo mock. **Se genera, no se edita** | — |
| `PENDIENTES_por_contrato.md` | Los 34 pendientes (`x-todo`) con a quién preguntar | Cada responsable |

## Cómo leer cada operación

- `summary`: qué hace.
- `x-historias`: historias de la PO que la justifican (BELCMW).
- `x-tarea`: tarea del backlog que la implementa (TEC).
- `x-todo`: lo que falta confirmar. Una operación con `x-todo` no se congela hasta resolverlo.
- `examples`: datos sintéticos del ejemplo de autogestión de la PO; también son las respuestas del mock.

## Estado verificado (1 de noviembre de 2026)

- Los 12 archivos son OpenAPI 3.0.3 válido y todos los `$ref` resuelven.
- 202 ejemplos validados contra su esquema, 0 errores.
- Mock completo: las 35 operaciones responden el código esperado.

## Levantar el mock completo

```
npx @stoplight/prism-cli@5.12.0 mock belc-mock-completo.yaml -p 4010
```

o con Docker:

```
docker run --rm -p 4010:4010 -v "$PWD":/api stoplight/prism:5 mock -h 0.0.0.0 /api/belc-mock-completo.yaml
```

Encabezados: `Authorization: Bearer <cualquier valor>` y `X-Correlation-Id: <UUID>`.
En afiliación, además `X-Invitation-Token: <cualquier valor>`.
Escenarios: `Prefer: example=<nombre>` o `Prefer: code=409, example=<nombre>`. Los nombres están en cada contrato.

## Reglas al editar

1. Se edita el contrato del dominio, nunca `belc-mock-completo.yaml`.
2. Un campo nuevo sale del DDL o de la historia; si no está en ninguno, se pregunta a Arquitectura.
3. Un código de error nuevo se agrega primero en `belc-api-comun.yaml` y en la guía.
4. Antes de pedir aprobación, el contrato pasa el validador automático del pipeline.
