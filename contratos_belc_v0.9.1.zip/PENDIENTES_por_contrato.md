# Pendientes por contrato (x-todo) · borradores v0.9

Cada responsable resuelve sus pendientes con la persona indicada, actualiza el YAML y quita el x-todo resuelto.

| Contrato | Responsable | Operaciones | Pendientes |
|---|---|---|---|
| sesion-contexto | Domingo Camargo | 2 | 3 |
| aprobaciones | Domingo Camargo | 1 | 1 |
| afiliacion | David Ríos | 2 | 3 |
| catalogos | Edwin Lima | 2 | 1 |
| usuarios | Raúl Rojas | 5 | 4 |
| productos | Raúl Rojas | 1 | 2 |
| roles | Edwin Lima | 5 | 3 |
| grupos-productos | Benjamín Rodríguez | 5 | 3 |
| flujos-aprobacion | David Ríos | 6 | 6 |
| backoffice | Héctor Durán con Jonathan Vargas (BO) | 6 | 8 |
| **Total** | | **35** | **34** |

## sesion-contexto.yaml · Domingo Camargo · 2 operaciones

- [ ] `GET /v1/sesion/contexto`: Confirmar con Gustavo (ForgeRock) qué claims trae el token: identificador de persona y contextos habilitados.
- [ ] `GET /v1/sesion/contexto`: Definir con la PO qué devuelve si la persona solo tiene contexto PERSONAL.
- [ ] `POST /v1/sesion/contexto`: Definir con BELP qué responde al pasar a contexto PERSONAL (redirección o token de BELP).

## aprobaciones.yaml · Domingo Camargo · 1 operaciones

- [ ] `GET /v1/grupos-economicos/{id}/aprobaciones-administrativas/{idAprobacion}`: Bandeja, aprobar y rechazar quedan en un contrato aparte (fuera de la v1).

## afiliacion.yaml · David Ríos · 2 operaciones

- [ ] `POST /v1/afiliaciones/validacion`: Confirmar con Gustavo (ForgeRock) cómo llega el token de invitación al journey y qué datos pide el journey.
- [ ] `POST /v1/afiliaciones/validacion`: Definir con Seguridad el máximo de intentos de validación por invitación.
- [ ] `POST /v1/afiliaciones/{enrollmentId}/vinculacion`: El nombre del parámetro {enrollmentId} viene del backlog; evaluar renombrarlo a {idAfiliacion} antes de congelar.

## catalogos.yaml · Edwin Lima · 2 operaciones

- [ ] `GET /v1/catalogos/{tipo}`: Definir tiempo de caché en el canal (los catálogos cambian solo por Liquibase).

## usuarios.yaml · Raúl Rojas · 5 operaciones

- [ ] `GET /v1/grupos-economicos/{id}/usuarios`: Confirmar con la PO los campos por los que busca "texto" (nombre, correo, documento).
- [ ] `POST /v1/grupos-economicos/{id}/usuarios`: Confirmar con la PO si empresa y tipo de visualización son obligatorios.
- [ ] `PUT /v1/grupos-economicos/{id}/usuarios/{idUsuario}`: Confirmar con la PO qué campos son editables (el DDL permite nombre, correo, rol, empresa y visualización).
- [ ] `PATCH /v1/grupos-economicos/{id}/usuarios/{idUsuario}/estado`: Confirmar con la PO si se puede inactivar a un administrador del grupo o al último aprobador de un flujo.

## productos.yaml · Raúl Rojas · 1 operaciones

- [ ] `GET /v1/grupos-economicos/{id}/productos`: Campos de saldo según el contrato de COBIS de Business Capabilities (TEC-012): disponible, contable, retenido.
- [ ] `GET /v1/grupos-economicos/{id}/productos`: Definir qué muestra si COBIS no responde (producto sin saldo o error parcial).

## roles.yaml · Edwin Lima · 5 operaciones

- [ ] `POST /v1/grupos-economicos/{id}/roles`: Confirmar con la PO si un administrador puede crear roles con perfil ADMINISTRADOR (hoy se excluye).
- [ ] `DELETE /v1/grupos-economicos/{id}/roles/{idRol}`: Confirmar con la PO qué pasa si el rol tiene usuarios asignados (bloquear con un código nuevo o reasignar).
- [ ] `DELETE /v1/grupos-economicos/{id}/roles/{idRol}`: Los roles de sistema (es_sistema) no se eliminan: definir el código de error.

## grupos-productos.yaml · Benjamín Rodríguez · 5 operaciones

- [ ] `POST /v1/grupos-economicos/{id}/grupos-productos`: Si se envía un producto de otro grupo económico, la base lo rechaza: confirmar si se responde 404 o 422.
- [ ] `DELETE /v1/grupos-economicos/{id}/grupos-productos/{idGrupoProducto}`: Confirmar con la PO qué pasa si el grupo está asignado a un rol (bloquear o quitarlo del rol).
- [ ] `DELETE /v1/grupos-economicos/{id}/grupos-productos/{idGrupoProducto}`: Los grupos de sistema (esSistema) no se eliminan: definir el código de error.

## flujos-aprobacion.yaml · David Ríos · 6 operaciones

- [ ] `POST /v1/grupos-economicos/{id}/flujos-aprobacion`: Definir con la PO si se permiten rangos de monto superpuestos para el mismo tipo de transacción y, si no, el código de error.
- [ ] `POST /v1/grupos-economicos/{id}/flujos-aprobacion`: Confirmar si los flujos deben pasar por aprobación administrativa (hoy no: el modelo no tiene tipo de cambio FLUJO).
- [ ] `PUT /v1/grupos-economicos/{id}/flujos-aprobacion/{idFlujo}`: Definir qué pasa con transacciones pendientes que usan el flujo al editarlo.
- [ ] `DELETE /v1/grupos-economicos/{id}/flujos-aprobacion/{idFlujo}`: Definir si se bloquea la eliminación cuando hay transacciones pendientes con ese flujo.
- [ ] `PUT /v1/grupos-economicos/{id}/flujos-aprobacion/{idFlujo}/reglas/{idRegla}/niveles`: BELCMW-38 no aparece en el backlog de la PO: confirmar si la historia sigue vigente o se unió con BELCMW-37.
- [ ] `PUT /v1/grupos-economicos/{id}/flujos-aprobacion/{idFlujo}/reglas/{idRegla}/niveles`: Confirmar que los aprobadores deben tener perfil Aprobador y el permiso de aprobar ese tipo de transacción.

## backoffice.yaml · Héctor Durán con Jonathan Vargas (BO) · 6 operaciones

- [ ] `General`: Seguridad del empleado según TEC-011 (login de BackOffice), pendiente de decisión.
- [ ] `POST /v1/grupos-economicos`: Confirmar si el grupo se crea solo con nombre o también con datos del cliente principal en COBIS.
- [ ] `GET /v1/empresas-core`: Campos de la respuesta según el contrato de COBIS de Business Capabilities (TEC-012).
- [ ] `GET /v1/grupos-economicos/{id}/empresas/{idEmpresa}/productos-core`: Ruta propuesta por Arquitectura: BO la confirma y actualiza TEC-009 en Jira.
- [ ] `GET /v1/grupos-economicos/{id}/empresas/{idEmpresa}/productos-core`: Campos según el contrato de COBIS (TEC-012).
- [ ] `POST /v1/grupos-economicos/{id}/productos-vinculados`: Ruta propuesta por Arquitectura: BO la confirma y actualiza TEC-009 en Jira.
- [ ] `POST /v1/grupos-economicos/{id}/administradores/invitaciones`: El rol que recibe el administrador es el rol de sistema del grupo (system_role_group_key): confirmar con BO que se crea al crear el grupo.
- [ ] `POST /v1/grupos-economicos/{id}/administradores/invitaciones`: Vigencia de la invitación (días) por definir con Seguridad.
