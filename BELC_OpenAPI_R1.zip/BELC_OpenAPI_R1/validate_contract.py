"""Validación OAS 3.0, referencias, ejemplos, trazabilidad y mock HTTP. No cambia fuentes."""
from pathlib import Path
import copy, importlib.util, json, re, sys, threading, urllib.request, urllib.error, warnings
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/".validation_deps"))
import yaml
from openapi_spec_validator import validate_url
from openapi_schema_validator import OAS30ReadValidator, OAS30WriteValidator
from jsonschema import RefResolver
from mock_server import Handler, SPEC, FIX, TOKENS, resolve
from http.server import ThreadingHTTPServer
warnings.filterwarnings("ignore",category=DeprecationWarning)
METHODS={"get","post","put","patch","delete"}
errors=[];checked=0;ops=[]

def check(cond,msg):
    if not cond:errors.append(msg)
def validate_example(value,schema,label,request=False):
    global checked
    try:
        cls=OAS30WriteValidator if request else OAS30ReadValidator
        validator=cls(schema,resolver=RefResolver.from_schema(SPEC),format_checker=cls.FORMAT_CHECKER)
        issues=list(validator.iter_errors(value))
        for e in issues:errors.append(f"{label}: {e.message} ({list(e.path)})")
        checked+=1
    except Exception as e:errors.append(f"{label}: {type(e).__name__}: {e}")

for f in [ROOT/"openapi-belc-v1.yaml",*(ROOT/"contratos").glob("*.yaml")]:
    try:validate_url(f.as_uri())
    except Exception as e:errors.append(f"{f.name}: {e}")
def walk(node):
    if isinstance(node,dict):
        if "$ref" in node:
            try:resolve(node)
            except Exception as e:errors.append("Referencia "+node["$ref"]+": "+str(e))
        for v in node.values():walk(v)
    elif isinstance(node,list):
        for v in node:walk(v)
walk(SPEC)
check(yaml.safe_load((ROOT/"openapi-belc-v1.yaml").read_text(encoding="utf-8"))==SPEC,"YAML y JSON divergen")
ids=set()
for path,item in SPEC["paths"].items():
    for method,op in item.items():
        if method not in METHODS:continue
        oid=op["operationId"];ops.append((path,method,op))
        check(oid not in ids,"operationId duplicado "+oid);ids.add(oid)
        check(bool(op.get("x-po-stories") or op.get("x-tec-tasks")),"Falta trazabilidad "+oid)
        check(bool(op.get("x-authorization-rule")),"Falta autorización "+oid)
        params=[resolve(p) for p in op.get("parameters",[])]
        for n in re.findall(r"{([^}]+)}",path):
            check(any(p["name"]==n and p["in"]=="path" and p.get("required") for p in params),"Parámetro path no declarado "+oid+" "+n)
        req=op.get("requestBody")
        if req:
            media=req["content"]["application/json"]
            validate_example(media["example"],media["schema"],oid+" request",True)
        success=False
        for status,response0 in op["responses"].items():
            response=resolve(response0)
            for mime,media in response.get("content",{}).items():
                examples=[e["value"] for e in media.get("examples",{}).values()]
                if "example" in media:examples.append(media["example"])
                for i,v in enumerate(examples):
                    validate_example(v,media["schema"],f"{oid} {status} example {i}")
                    if mime=="application/problem+json":
                        check(v["status"]==int(status),"HTTP de ejemplo inconsistente "+oid)
                        check("errors" not in v or int(status)==400,"errors[] fuera de 400 "+oid)
                if status.startswith("2") and examples:success=True
        check(success,"Sin ejemplo de éxito "+oid)
        if "202" in op["responses"]:
            check("Location" in op["responses"]["202"]["headers"],"202 sin seguimiento "+oid)
            check(any(resolve(p)["name"]=="Idempotency-Key" for p in params),"202 sin clave idempotente "+oid)
# Propiedades de datos de prueba y exposición.
check(len(FIX["empresas"])==3 and len(FIX["roles"])==4 and len(FIX["usuarios"])==7,"Fixture PO incompleto")
for user in FIX["usuarios"]:
    r=next((r for r in FIX["roles"] if r["idRol"]==user["idRol"]),None)
    check(r is not None and r["codigoPerfil"]==user["codigoPerfil"],"Perfil incoherente en fixture")
for name in ["Usuario","Rol","GrupoProductos","Producto","EstadoSolicitud"]:
    props=SPEC["components"]["schemas"][name].get("properties",{})
    check(not any(k in props for k in ["person_id","idPersona","identityId","token","tokenHash","numeroCuenta"]),"Exposición indebida "+name)
# Pruebas negativas de forma: las entradas no aceptan el actor impuesto ni versión ausente.
v=copy.deepcopy(SPEC["components"]["schemas"]["EditarRol"])
example=next(op["requestBody"]["content"]["application/json"]["example"] for _,_,op in ops if op["operationId"]=="solicitarEdicionRol")
bad=copy.deepcopy(example);bad.pop("version")
validator=OAS30WriteValidator(v,resolver=RefResolver.from_schema(SPEC))
check(bool(list(validator.iter_errors(bad))),"Editar rol acepta versión ausente")
bad=copy.deepcopy(example);bad["person_id"]="otro"
check(bool(list(validator.iter_errors(bad))),"Editar rol acepta actor en cuerpo")
# Levantar servidor efímero solo para pruebas y cerrarlo al terminar.
server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base=f"http://127.0.0.1:{server.server_address[1]}"
httpchecks=0
def request(path,method="GET",body=None,headers=None):
    global httpchecks
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(base+path,data=data,method=method,headers=headers or {})
    try:
        with urllib.request.urlopen(req,timeout=5) as res:result=(res.status,json.load(res),dict(res.headers))
    except urllib.error.HTTPError as e:result=(e.code,json.load(e),dict(e.headers))
    httpchecks+=1
    return result
def test_params(path,op):
    values={"id":1,"idUsuario":1,"idRol":2,"idGrupoProducto":2,"idFlujo":1,"idRegla":1,
            "idEmpresa":1,"enrollmentId":101,"idAprobacion":9001,"tipo":"monedas","codigo":"CREADOR"}
    path=re.sub(r"{([^}]+)}",lambda m:str(values[m.group(1)]),path)
    queries=[]
    headers={"X-Correlation-Id":"test-correlation-0001"}
    if op.get("security"):
        scheme=next(iter(op["security"][0]));headers["Authorization"]="Bearer "+TOKENS[scheme]
    for p0 in op.get("parameters",[]):
        p=resolve(p0)
        if not p.get("required") or p["in"]=="path":continue
        if p["in"]=="header":headers[p["name"]]="test-idempotency-key-0001"
        if p["in"]=="query":queries.append(p["name"]+"="+("CIF-DEMO-001" if p["name"]=="identificacion" else "1"))
    if queries:path+="?"+"&".join(queries)
    body=op.get("requestBody",{}).get("content",{}).get("application/json",{}).get("example")
    if body is not None:headers["Content-Type"]="application/json"
    return path,headers,body
try:
    for path,method,op in ops:
        url,headers,body=test_params(path,op)
        status,value,rh=request(url,method.upper(),body,headers)
        check(str(status) in op["responses"] and status<300,f"Mock éxito {op['operationId']}: {status} {value}")
        if str(status) in op["responses"]:
            media=op["responses"][str(status)]["content"]
            schema=next(iter(media.values()))["schema"]
            validate_example(value,schema,"HTTP "+op["operationId"])
        check(rh.get("X-Correlation-Id")==headers["X-Correlation-Id"],"Correlación perdida")
        for code in op["x-error-codes"]:
            status,v,_=request(url,method.upper(),body,{**headers,"X-Mock-Scenario":code})
            expected=next(e["content"]["application/problem+json"]["examples"][code]["value"]["status"]
                          for e in op["responses"].values()
                          if code in e.get("content",{}).get("application/problem+json",{}).get("examples",{}))
            check(status==expected and v.get("code")==code,"Mock error "+op["operationId"]+" "+code)
    status,v,_=request("/v1/grupos-economicos/2/usuarios",headers={"Authorization":"Bearer mock-cliente"})
    check(status==404 and v["code"]=="BELC-GEN-004","No oculta otro grupo")
    status,v,_=request("/v1/sesion/contexto")
    check(status==401,"Sin credencial mock no devuelve 401")
    status,v,_=request("/v1/backoffice/grupos-economicos","POST",{"nombre":"x","tipoAdministracion":"I"},
                     {"Authorization":"Bearer mock-cliente","Content-Type":"application/json","Idempotency-Key":"abcdefghijklmnop"})
    check(status==403,"Empleado y cliente no separados en mock")
    status,v,_=request("/v1/grupos-economicos/1/aprobaciones-administrativas/9001",
                     headers={"Authorization":"Bearer mock-cliente","X-Mock-Scenario":"aplicada"})
    check(status==200 and v["estado"]=="APLICADA" and v["idRecurso"] is not None,"Seguimiento final no funciona")
    status,v,_=request("/v1/grupos-economicos/1/usuarios?tamano=101",headers={"Authorization":"Bearer mock-cliente"})
    check(status==400,"Paginación sin límite")
    status,v,_=request("/v1/grupos-economicos/1/usuarios/2",headers={"Authorization":"Bearer mock-cliente"})
    check(status==200 and v["idUsuario"]==2,"Detalle de usuario no resuelve fixture correcto")
finally:
    server.shutdown();server.server_close();thread.join(timeout=2)
report={"openapi":"3.0.3","version":SPEC["info"]["version"],"operations":len(ops),
        "documents_validated":len(list((ROOT/"contratos").glob("*.yaml")))+1,
        "examples_validated":checked,"http_checks":httpchecks,"errors":errors,
        "scope":"Esquemas, referencias, ejemplos, trazabilidad y mock local. No prueba backend, ForgeRock real, COBIS, DDL en motor ni aprobación funcional."}
(ROOT/"docs/validacion.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report,ensure_ascii=True))
raise SystemExit(1 if errors else 0)

