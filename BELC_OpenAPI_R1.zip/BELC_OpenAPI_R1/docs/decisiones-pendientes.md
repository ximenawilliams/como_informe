# Decisiones para congelar el contrato

No requieren detener borradores, mocks o clientes. La versión entregada es candidata.

| Id | Decisión | Efecto | Responsable sugerido |
|---|---|---|---|
| D-01 | Confirmar ADR-004: 202, política individual/dual y seguimiento propuesto. | La pantalla muestra pendientes; motor/decisiones en otra historia. Incorporar 202 al catálogo HTTP. | Arquitectura + PO + BE |
| D-02 | Activar AFI-001/APR-002 reservados y aceptar los 12 códigos propuestos. Resolver EMP-003/PRD-002. | Estabilidad del catálogo. EMP-003 refleja la unicidad actual del DDL; consulta sin productos devuelve 200 vacío. | PO + Arquitectura + BE |
| D-03 | Audiencias/claims finales de cliente, journey y empleado BO. Soft token vs invitación BELCMW-5. | ForgeRock ya es fuente de identidad. No crear maestro ni exponer person_id de terceros. | IAM + Seguridad + BO |
| D-04 | Idempotency-Key requerido, ámbito, TTL y almacenamiento durable. | Evitar duplicados. El DDL no incluye un almacén específico; diseñar implementación separada. | BE + Arquitectura |
| D-05 | Emisión/verificación del comprobante opaco de correo por OTP. | Vinculación y edición de correo. No confiar en fecha o booleano enviados por browser ni inventar endpoint OTP. | IAM/Notificaciones + BE |
| D-06 | Contexto de sesión y coordinación BELP/BELC. | GET/POST propuestos mantienen sesión; el contexto no concede permisos. Mock no prueba SSO. | IAM + Arquitectura + Web/App |
| D-07 | BELCMW-38, alcance R1 y actualización de reglas con niveles existentes. | Evitar perder niveles al reemplazar reglas. Versionado optimista no es historia inmutable R2. | PO + BE |
| D-08 | Semillas de perfiles/permisos, EJECUTOR y bootstrap de sistema. | DDL solo inserta ADMINISTRADOR y remite a otro SQL. Ejemplos no son semillas oficiales. | PO + Arquitectura + BO |
| D-09 | Paginación independiente de invitaciones y productos sin grupo. | Colecciones auxiliares acotadas por tamano y paginado principal; evaluar endpoint separado. | Web/App + BE |

BackOffice usa /v1/backoffice/... para separar audiencias y políticas. El backlog previo tenía rutas sin ese prefijo. Confirmar mapeo con Gateway y registrar la ruta final en Jira.

Se contaron 35 operaciones incluyendo seguimiento y consultas/vinculaciones de productos BO. Reconciliar con el mapa de 32 de TEC-117; conservar cobertura.

El alcance funcional lo acuerda la PO; Arquitectura y consumidores validan integración. Mantener decisiones por contrato y versión de commit/release.

Versiones: /v1 es la mayor de API; openapi: 3.0.3 es la especificación; info.version: 1.0.0-rc.1 identifica este candidato. Evaluar compatibilidad ante cambios de tipos, obligatoriedad, formatos, enum y semántica.

El bundle autónomo evita problemas de resolución de referencias externas en herramientas del equipo.

