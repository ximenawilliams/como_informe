# Reglas que acompañan a los contratos

## Identidad y ámbito

- ForgeRock es autoridad de identidad; person_id es la referencia central acordada. Las claves locales no necesitan coincidir con BELP.
- El actor procede de credenciales verificadas; idUsuario identifica group_user_id local, no person_id de terceros.
- Cliente: token válido, BELC habilitado, registro comercial y membresía activos, y permiso efectivo.
- BackOffice: empleado autorizado, sin exigir membresía de cliente en el grupo.
- Vinculación: credencial del journey y vínculo actor–invitación; no exigir una membresía aún no creada.
- Sin permiso general: 403. Recurso fuera del ámbito: 404.
- Inactivar una membresía no deshabilita ForgeRock, otros grupos ni BELP.
- Ninguna API de este paquete consulta toda la bitácora.

## Escritura y aprobación

- Usuarios, roles y grupos se registran como propuestas 202, sin cambiar la entidad operativa.
- Usar snapshots ANTERIOR/PROPUESTO en las tablas tipadas belpc_admin_approval_<tipo>.
- Validar grupo, permisos, versión, referencias en uso y mínimos de administradores al solicitar y al aplicar.
- Preservar detalle inmutable tras la primera decisión y verificar proposed_hash. No aceptar hash del browser.
- No entregar un id de recurso operativo inventado para altas pendientes.
- 409 BELC-GEN-005 para concurrencia inicial; conflictos al aplicar aparecen en el estado de seguimiento.
- FALLIDA/resultado VERSION_DESACTUALIZADA es una propuesta funcional; no expone failure_reason interno.
- Cambiar hijos incrementa y comprueba la versión del padre en una transacción.
- DATETIME se escribe en UTC por servidor; no aceptar fecha de auditoría del cliente.
- Política individual/dual y autoaprobación pendientes D-01. No hay API de decisión en este paquete.

## Idempotencia y notificaciones

- Mismo actor, operación, grupo, clave y payload devuelve la misma solicitud/recurso.
- Clave reutilizada con otro payload: conflicto.
- Generar token de invitación en servidor y persistir solo hash; no devolver token por HTTP.
- En alta secundaria, correo e invitación nacen al aplicar la aprobación. BO tiene bootstrap autorizado.
- Consumir invitación atómicamente; replay por misma persona es idempotente.
- Verificar correo mediante prueba opaca ligada a propósito, destinatario, grupo y vigencia.
- Cambio de negocio y evento son atómicos en la conexión o usan mecanismo recuperable acordado.
- Entrega de correo requiere recuperación/idempotencia; un commit SQL no prueba entrega.
- Estas garantías corresponden al backend, no al mock.

## Productos y privacidad

- company_id de la membresía es informativo. La visibilidad la dan rol y grupos de productos.
- Proteger rol y grupo de sistema; no permitir editar is_system desde UI.
- Devolver referencias locales y números enmascarados al cliente.
- Las referencias core de BO deben ser opacas; tokenizar si contienen números de cuenta reales.
- Documento completo solo como entrada necesaria; nunca en respuestas o logs.
- Fixtures ficticios example.invalid. No usar datos reales en el mock.
- Consultar saldos en core/BC sin persistir ni fabricar ceros en caso de error.
- DECIMAL(18,2) se transporta como cadena exacta; confirmar convención antes de generar clientes.

## Pruebas de backend requeridas

- Validación de contrato y reglas que OpenAPI no puede expresar.
- 401/403/404 entre grupos, concurrencia, idempotencia y errores core.
- Bootstrap completo: grupo → productos → invitación → vinculación → autogestión.
- Resultado final de solicitud, además del 202 inicial.
- Regresión BELP e independencia de rutas/desactivación antes de producción.

