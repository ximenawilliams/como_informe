"""Consolida los nueve contratos modulares y componentes locales; requiere PyYAML."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/".validation_deps"))
import yaml
FILES=["sesion-contexto","afiliacion","catalogos","usuarios","roles","grupos-productos",
       "productos","flujos-aprobacion","backoffice"]
def localize(node):
    if isinstance(node,list):return [localize(x) for x in node]
    if isinstance(node,dict):
        out={}
        for k,v in node.items():
            if k=="$ref" and isinstance(v,str):
                if not v.startswith("belc-api-comun.yaml#/components/"):
                    raise ValueError("Referencia externa no prevista: "+v)
                out[k]=v.removeprefix("belc-api-comun.yaml")
            else:out[k]=localize(v)
        return out
    return node
common=yaml.safe_load((ROOT/"contratos/belc-api-comun.yaml").read_text(encoding="utf-8"))
root=None
for name in FILES:
    doc=yaml.safe_load((ROOT/f"contratos/{name}.yaml").read_text(encoding="utf-8"))
    if root is None:
        root={k:v for k,v in doc.items() if k not in ("paths","components")}
        root["info"]={**root["info"],"title":"BELC · API R1"}
        root["paths"]={}
    if doc["info"]["version"]!=root["info"]["version"]:raise ValueError("Versiones de contratos diferentes")
    for path,item in localize(doc["paths"]).items():
        target=root["paths"].setdefault(path,{})
        for method,op in item.items():
            if method in target:raise ValueError("Operación duplicada: "+method+" "+path)
            target[method]=op
root["components"]=common["components"]
if "--check" in sys.argv:
    current=json.loads((ROOT/"openapi-belc-v1.json").read_text(encoding="utf-8"))
    if root!=current:raise SystemExit("El consolidado no coincide con los contratos modulares")
    print("Consolidado y contratos modulares coinciden")
else:
    (ROOT/"openapi-belc-v1.yaml").write_text(yaml.safe_dump(root,allow_unicode=True,sort_keys=False,width=110),encoding="utf-8")
    (ROOT/"openapi-belc-v1.json").write_text(json.dumps(root,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print("Consolidado regenerado. Ejecutar validate_contract.py antes de compartir.")

