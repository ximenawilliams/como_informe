"""Mock de ejemplos BELC. Python >=3.10, sin dependencias. Escucha solo en loopback."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
import argparse, copy, json, re, uuid

ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/"openapi-belc-v1.json").read_text(encoding="utf-8"))
FIX=json.loads((ROOT/"examples/datos-sinteticos.json").read_text(encoding="utf-8"))
METHODS={"get","post","put","patch","delete"}
ROUTES=[]
for path,item in SPEC["paths"].items():
    pattern="^"+re.sub(r"\\{([^}]+)\\}",lambda m:"(?P<"+m.group(1)+">[^/]+)",re.escape(path))+"$"
    # re.escape also escapes braces; build by literal/template fragments.
    parts=re.split(r"({[^}]+})",path)
    pattern="^"+"".join("(?P<"+p[1:-1]+">[^/]+)" if p.startswith("{") else re.escape(p) for p in parts)+"$"
    ROUTES.append((re.compile(pattern),path,item))
TOKENS={"ForgeRockCliente":"mock-cliente","ForgeRockJourney":"mock-journey","BackOffice":"mock-empleado"}

def resolve(node):
    while isinstance(node,dict) and "$ref" in node:
        ptr=node["$ref"]
        if not ptr.startswith("#/"):raise ValueError("El mock usa el contrato consolidado.")
        node=SPEC
        for part in ptr[2:].split("/"):
            node=node[part.replace("~1","/").replace("~0","~")]
    return node

def validate_value(value,schema,path="$"):
    """Validaciones de forma para el mock; no sustituye validación OAS ni lógica de negocio."""
    s=resolve(schema)
    if value is None and s.get("nullable"):return []
    errs=[]
    typ=s.get("type")
    valid={"object":isinstance(value,dict),"array":isinstance(value,list),
           "string":isinstance(value,str),"integer":isinstance(value,int) and not isinstance(value,bool),
           "number":isinstance(value,(int,float)) and not isinstance(value,bool),"boolean":isinstance(value,bool)}
    if typ and not valid.get(typ,True):return [(path,"Tipo esperado: "+typ)]
    if "enum" in s and value not in s["enum"]:errs.append((path,"Valor fuera del enum"))
    if isinstance(value,dict):
        for k in s.get("required",[]):
            if k not in value:errs.append((path+"."+k,"Campo obligatorio"))
        for k,v in value.items():
            if k in s.get("properties",{}):errs+=validate_value(v,s["properties"][k],path+"."+k)
            elif s.get("additionalProperties") is False:errs.append((path+"."+k,"Campo no permitido"))
    if isinstance(value,str):
        if len(value)<s.get("minLength",0) or len(value)>s.get("maxLength",10**9):errs.append((path,"Longitud no válida"))
        if "pattern" in s and re.search(s["pattern"],value) is None:errs.append((path,"Formato no válido"))
        if s.get("format")=="email" and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",value):errs.append((path,"Correo no válido"))
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        if value<s.get("minimum",float("-inf")) or value>s.get("maximum",float("inf")):errs.append((path,"Valor fuera de rango"))
    if isinstance(value,list):
        if len(value)<s.get("minItems",0) or len(value)>s.get("maxItems",10**9):errs.append((path,"Cantidad no válida"))
        if s.get("uniqueItems") and len({json.dumps(v,sort_keys=True) for v in value})!=len(value):errs.append((path,"Elementos repetidos"))
        for i,v in enumerate(value):errs+=validate_value(v,s["items"],path+f"[{i}]")
    return errs

def error_example(code,path,corr):
    for r in SPEC["components"]["responses"].values():
        media=r.get("content",{}).get("application/problem+json",{})
        v=media.get("example")
        if v and v["code"]==code:
            out=copy.deepcopy(v);out.update(instance=path,correlationId=corr);return out
    raise ValueError(code)

class Handler(BaseHTTPRequestHandler):
    server_version="BELC-Mock/1"
    def log_message(self,fmt,*args):
        # No registrar URL, cuerpos, credenciales ni query con datos.
        pass
    def send(self,status,value,corr,headers=None,problem=False):
        body=json.dumps(value,ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/problem+json" if problem else "application/json")
        self.send_header("Content-Length",str(len(body)))
        self.send_header("X-Correlation-Id",corr)
        self.send_header("Cache-Control","no-store")
        self.send_header("X-BELC-Mock","true")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Expose-Headers","X-Correlation-Id, Location, Retry-After, X-BELC-Mock")
        for k,v in (headers or {}).items():self.send_header(k,str(v))
        self.end_headers();self.wfile.write(body)
    def error(self,code,path,corr,fields=None):
        value=error_example(code,path,corr)
        if fields is not None:value["errors"]=[{"field":p,"message":m} for p,m in fields]
        headers={}
        if value["status"]==401:headers["WWW-Authenticate"]="Bearer"
        if value["status"] in (429,503):headers["Retry-After"]="30"
        self.send(value["status"],value,corr,headers,True)
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Methods","GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers","Authorization, Content-Type, X-Correlation-Id, Idempotency-Key, X-Mock-Scenario")
        self.end_headers()
    def handle_api(self):
        url=urlsplit(self.path)
        corr=self.headers.get("X-Correlation-Id") or str(uuid.uuid4())
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}",corr):
            self.error("BELC-GEN-001",url.path,str(uuid.uuid4()),[("X-Correlation-Id","Formato no válido")]);return
        if url.path=="/health":
            self.send(200,{"status":"ok","mock":True,"version":SPEC["info"]["version"]},corr);return
        found=None
        for pattern,path,item in ROUTES:
            m=pattern.match(url.path)
            if m:
                op=item.get(self.command.lower())
                if op:found=(op,m.groupdict());break
        if found is None:
            self.error("BELC-GEN-004",url.path,corr);return
        op,pp=found
        sec=op.get("security",[])
        if sec:
            scheme=next(iter(sec[0]))
            supplied=self.headers.get("Authorization","")
            if not supplied.startswith("Bearer ") or supplied[7:] not in TOKENS.values():
                self.error("BELC-GEN-002",url.path,corr);return
            if supplied[7:]!=TOKENS[scheme]:
                self.error("BELC-GEN-003",url.path,corr);return
        qp=parse_qs(url.query,keep_blank_values=True)
        fields=[]
        for p0 in op.get("parameters",[]):
            p=resolve(p0);loc=p["in"];name=p["name"]
            value=pp.get(name) if loc=="path" else qp.get(name,[None])[0] if loc=="query" else self.headers.get(name)
            if value is None:
                if p.get("required"):fields.append((name,"Campo obligatorio"))
                continue
            schema=resolve(p["schema"])
            if schema.get("type")=="integer":
                try:value=int(value)
                except ValueError:fields.append((name,"Entero requerido"));continue
            fields+=validate_value(value,schema,name)
        try:length=int(self.headers.get("Content-Length","0"))
        except ValueError:length=-1
        if not 0<=length<=1024*1024:
            self.error("BELC-GEN-001",url.path,corr,[("body","Tamaño no válido")]);return
        raw=self.rfile.read(length)
        req=op.get("requestBody")
        if req:
            if self.headers.get("Content-Type","").split(";")[0].strip()!="application/json":
                fields.append(("Content-Type","Se requiere application/json"))
            try:body=json.loads(raw)
            except (ValueError,UnicodeDecodeError):fields.append(("body","JSON no válido"));body=None
            if body is not None:fields+=validate_value(body,req["content"]["application/json"]["schema"])
        if fields:
            self.error("BELC-GEN-001",url.path,corr,fields);return
        # Solo grupo sintético 1; el mock no concede acceso al indicar otro grupo.
        if "id" in pp and pp["id"]!="1":
            self.error("BELC-GEN-004",url.path,corr);return
        scenario=self.headers.get("X-Mock-Scenario","exito")
        chosen=None
        for status,response0 in op["responses"].items():
            response=resolve(response0)
            for mime,media in response.get("content",{}).items():
                for key,example in media.get("examples",{}).items():
                    if key==scenario:chosen=(int(status),copy.deepcopy(example["value"]),mime,response);break
                if chosen:break
            if chosen:break
        if chosen is None:
            self.error("BELC-GEN-001",url.path,corr,[("X-Mock-Scenario","Escenario no definido para esta operación")]);return
        status,value,mime,response=chosen
        if isinstance(value,dict) and "correlationId" in value:value["correlationId"]=corr
        if scenario=="exito":
            lookup={"consultarUsuario":("idUsuario","usuarios","idUsuario"),
                    "consultarRol":("idRol","roles","idRol"),
                    "consultarGrupoProductos":("idGrupoProducto","gruposProductos","idGrupoProducto")}
            if op["operationId"] in lookup:
                par,collection,key=lookup[op["operationId"]]
                item=next((v for v in FIX[collection] if v[key]==int(pp[par])),None)
                if item is None:self.error("BELC-GEN-004",url.path,corr);return
                value=item
        if mime=="application/json" and isinstance(value,dict) and "elementos" in value:
            # Paginación del conjunto sintético; filtros de negocio complejos no simulados.
            page=int(qp.get("pagina",["1"])[0]);size=int(qp.get("tamano",["25"])[0])
            elements=value["elementos"]
            value={**value,"elementos":elements[(page-1)*size:page*size],"pagina":page,"tamano":size,"totalElementos":len(elements)}
        headers={}
        for k,h0 in response.get("headers",{}).items():
            h=resolve(h0)
            if k!="X-Correlation-Id" and "example" in h:headers[k]=h["example"]
        self.send(status,value,corr,headers,mime=="application/problem+json")
    do_GET=do_POST=do_PUT=do_PATCH=do_DELETE=handle_api

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port",type=int,default=4010)
    args=parser.parse_args()
    server=ThreadingHTTPServer(("127.0.0.1",args.port),Handler)
    print(f"BELC mock http://127.0.0.1:{args.port} (Ctrl+C para detener)",flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=="__main__":main()

