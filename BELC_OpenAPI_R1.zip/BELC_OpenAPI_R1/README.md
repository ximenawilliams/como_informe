# BELC R1 · Contratos OpenAPI para desarrollo

Versión de trabajo: **1.0.0-rc.1**, OpenAPI **3.0.3**, preparada el **2 de noviembre de 2026**. Base de desarrollo candidata a revisión; el congelamiento y la aprobación no se presuponen.

## Empezar

1. Importar **openapi-belc-v1.yaml** en Swagger Editor, Postman o la herramienta de generación de clientes. Es autónomo y no requiere resolver archivos externos.
2. Para trabajar por dominio, usar **contratos/** conservando **belc-api-comun.yaml** en el mismo directorio.
3. Ejecutar el mock con Python 3.10 o superior; no requiere instalar dependencias:

~~~powershell
python .\mock_server.py --port 4010
~~~

4. Consultar un ejemplo:

~~~powershell
Invoke-RestMethod 'http://127.0.0.1:4010/v1/sesion/contexto' -Headers @{Authorization='Bearer mock-cliente'; 'X-Correlation-Id'='demo-correlation-0001'}
~~~

Credenciales **exclusivamente sintéticas** del mock:

| Actor | Authorization |
|---|---|
| Cliente BELC | Bearer mock-cliente |
| Persona completando registro | Bearer mock-journey |
| Empleado de BackOffice | Bearer mock-empleado |

La validación de invitación previa al login usa token de invitación y documento en el cuerpo, sin sesión de cliente. El mock no conecta a ForgeRock, COBIS, AWS ni a bases reales; los tokens de producción no sirven en él.

## Entregables y cobertura

| Archivo | Uso |
|---|---|
| openapi-belc-v1.yaml | Contrato completo, 35 operaciones, listo para importar. |
| openapi-belc-v1.json | La misma especificación para herramientas JSON y mock. |
| contratos/*.yaml | Nueve documentos de dominio más componentes comunes. |
| docs/matriz-operaciones.csv | Método, ruta, operationId, historias PO, tareas técnicas, tablas, actor y decisiones. |
| docs/mapeo-ddl.csv | Correspondencias relevantes de DTO y persistencia. |
| docs/catalogo-errores-fuente.csv | Los 23 códigos del Excel original, conservando estado y reintentabilidad. |
| docs/propuestas-catalogo-errores.csv | Doce códigos adicionales propuestos, pendientes de incorporación. |
| docs/decisiones-pendientes.md | Confirmaciones necesarias antes de congelar v1. |
| docs/reglas-implementacion.md | Autorización, consistencia, aprobación, idempotencia y privacidad. |
| docs/procedencia.json | Fuentes y SHA-256. |
| docs/validacion.json | Resultado y alcance de verificaciones ejecutadas. |
| examples/datos-sinteticos.json | Tres empresas, cuatro roles, siete usuarios y siete productos. |
| mock_server.py | Servidor local de ejemplos. |
| validate_contract.py | Validación reproducible de especificación, ejemplos y mock. |

Distribución de operaciones: sesión y seguimiento 3; afiliación 2; catálogos 2; usuarios 5; roles 5; grupos de productos 5; productos 1; flujos 6; backoffice 6. Son **métodos + rutas**, no cantidad de microservicios. Se incluyen las consultas/vinculaciones de productos BO, sin forzar el total de 32 de TEC-117.

Las capturas del 1 de noviembre muestran una parte de las 112 actividades de Jira, no una exportación completa. Se reutilizan historias observadas previamente en esta conversación cuando no están completas en estas fotos. BELCMW-38 tiene trazabilidad previa, pero su definición funcional necesita confirmación. BELCMW-5 (token) y BELCMW-13 (notificación) no se convierten automáticamente en APIs públicas nuevas.

Frecuentes, ejecución monetaria R2, bandeja y decisiones administrativas, estados de cuenta e implementación del backend quedan fuera de este paquete. Hay una **consulta mínima de seguimiento** para consumir la respuesta 202.

## Regla de éxito asíncrono

Se conserva TEC-117: solicitar creación/edición/inactivación de usuarios, roles o grupos de productos devuelve **202**, **idAprobacion** y **Location**. El recurso operativo todavía no cambió.

- Mostrar una solicitud pendiente, no un recurso ya aplicado.
- Consultar GET /v1/grupos-economicos/{id}/aprobaciones-administrativas/{idAprobacion}.
- Un alta pendiente no debe redirigir al detalle de un recurso que aún no existe.
- APROBADA y APLICADA son distintos: APROBADA no implica recurso actualizado.
- Los flujos se configuran directamente con 200/201 según TEC-117.
- El bootstrap BO usa 201; no exige una aprobación de cliente que aún no existe.
- La invitación secundaria y el correo se generan al aplicar la solicitud aprobada.

ADR-004 no se adjuntó y el Excel de HTTP no incluye 202: registrar confirmación en **D-01** antes de congelar. No se supone que individual/dual permita autoaprobación; la política y el motor se definen en otra historia.

## Escenarios del mock

Escucha **solo en 127.0.0.1**. Para que una App en otro dispositivo lo consuma, publicar en un DEV aprobado; este paquete no publica infraestructura ni abre acceso externo.

Elegir un error documentado para esa operación mediante **X-Mock-Scenario**:

~~~powershell
Invoke-RestMethod 'http://127.0.0.1:4010/v1/grupos-economicos/1/roles/2' -Headers @{Authorization='Bearer mock-cliente'; 'X-Mock-Scenario'='BELC-GEN-004'}
~~~

Los escenarios se consultan en responses/.../examples de cada operación. BELC-GEN-005 solo está disponible en escrituras con conflicto de versión.

Seguimiento con ejemplo final:

~~~powershell
Invoke-RestMethod 'http://127.0.0.1:4010/v1/grupos-economicos/1/aprobaciones-administrativas/9001' -Headers @{Authorization='Bearer mock-cliente'; 'X-Mock-Scenario'='aplicada'}
~~~

Estados de ejemplo: exito (= pendiente), aprobada, aplicada, rechazada, expirada, cancelada y fallida. Los detalles de usuarios/roles/grupos responden según IDs sintéticos existentes. Solo el grupo 1 tiene fixtures; otro grupo devuelve 404.

El mock **no persiste cambios ni ejecuta aprobaciones**. Los filtros complejos y transiciones son ejemplos seleccionados, no un backend completo. Verifica formas básicas, headers, credenciales sintéticas por actor y paginación. Un 403 del mock no prueba autorización real.

En escrituras enviar **Idempotency-Key**, de al menos 16 caracteres. Consultar requestBody/example para los cuerpos. El mock no mantiene un almacén de idempotencia.

## Errores

Se respeta el Excel: RFC 9457, application/problem+json y extensiones **code**, **correlationId**, **retryable**, **errors**.

- Token inválido: 401.
- Sin permiso o BELC deshabilitado: 403.
- Recurso inexistente o de otro grupo: **404**, para evitar enumeración.
- errors[] se entrega solo con 400.
- retryable no autoriza reintentar escrituras automáticamente: respetar idempotencia y refrescar versión.
- AFI-001 y APR-* siguen identificados como **Reservado**.
- EMP-003 y PRD-002 conservan **Por confirmar**.
- Los códigos nuevos son **Propuesto**; requieren incorporación. No se modificó el Excel original.

Los ejemplos permiten avanzar en desarrollo; no declaran aprobados los códigos o reglas pendientes.

## Validar en el equipo

Mock sin paquetes. Para verificaciones completas:

~~~powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe .\validate_contract.py
~~~

El validador comprueba OpenAPI, $ref, ejemplos, trazabilidad, seguridad declarada, equivalencia YAML/JSON y HTTP del mock. Abre un puerto efímero de prueba y lo cierra. Las políticas locales pueden requerir habilitar la conexión loopback.

Los resultados no verifican implementación, IAM real, core, ejecución del DDL ni producción.

## Fuentes y precedencia

1. **belc_ddl_v4 (5).sql**: tablas belpc_, tamaños, claves y estados.
2. **Catalogo_Errores_BEL_Comercial.xlsx**: códigos, HTTP, privacidad y claves de error.
3. Capturas Jira **2026-11-01**: historias y vínculos visibles.
4. TEC-117 y contexto acordado: español camelCase, ForgeRock, separación BELP/BELC, auditoría común y 202.
5. Propuestas explícitas en docs/decisiones-pendientes.md.

No se recibió diccionario v4, guía OpenAPI, ADR-004 ni semillas completas. Los nombres JSON son propuestas consistentes con el backlog español; el mapeo al DDL inglés está documentado. Las fuentes se dejaron intactas.

Referencias: [OpenAPI 3.0.3](https://spec.openapis.org/oas/v3.0.3.html), [RFC 9457](https://www.rfc-editor.org/rfc/rfc9457.html), [HTTP 202](https://www.rfc-editor.org/rfc/rfc9110.html#section-15.3.3).

